#!/bin/sh

server="https://licenses.cryptocom.ru/licgen4.php"
instpath="/opt/cryptopack4"
licfname="cryptocom.lic"
licfile=$instpath/ssl/$licfname
updaterpath=$instpath/bin/updater

if [ ! -x $updaterpath ]; then
	echo "Updater not found: $updaterpath not exists or not executable"
	exit 1;
fi

if  [ -s $licfile ] && [ "$1" != "-f" ]; then
	echo "License file already exists ($licfile)"
	exit 0;
fi;

if [ "`uname`" = "SunOS" ] ; then
	echo "Enter license key: "
else
	echo -n "Enter license key: "
fi
read key
if [ "$key" != "" ]; then
	$instpath/bin/updater -n -k $key -s $server -l $licfile
fi
